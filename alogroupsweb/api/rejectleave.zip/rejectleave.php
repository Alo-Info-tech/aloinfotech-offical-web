<?php
$to = 'arokiaanialogroups@gmail.com';
$subject = 'Regarding Leave';
$from = 'arokiaani2423@gmail.com';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Create email headers
$headers .= 'From: ' . $from . "\r\n" .
    'Reply-To: ' . $from . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Compose a simple HTML email message
$message = '<html><body>';
$message .= '<h1 style="color:#f40;">Hi Ani!</h1>';
$message .= '<p style="color:#080;font-size:18px;">Your Permission for leave has rejected</p>';
$message .= '</body></html>';

// Sending email
if (mail($to, $subject, $message, $headers)) {
    echo 'Permission Denied';
} else {
    echo 'Unable to send email. Please try again.';
}
